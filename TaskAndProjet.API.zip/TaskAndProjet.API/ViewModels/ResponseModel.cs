﻿namespace TaskAndProjet.API.ViewModels
{
    public class ResponseModel
    {
        public bool Success { get; set; }
        public string Message { get; set; } = string.Empty; 
    }
}
